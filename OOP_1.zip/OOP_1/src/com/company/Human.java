package com.company;

public abstract class Human {
    private String name;

    public void sleep() {
        System.out.println("I sleep");

    }
}