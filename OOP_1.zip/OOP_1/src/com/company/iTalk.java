package com.company;

public interface iTalk {
    void talk();
}
